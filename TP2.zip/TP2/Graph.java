import java.util.Vector;
import java.util.Queue;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Stack;
import java.util.Comparator;
import java.util.Set;
import java.util.List;
import java.util.HashSet;
//import java.util.*;

enum Color{WHITE, GRAY, BLACK}

class VertexAttributes{
	Color color;
	int pred;
	int d;
	int f;
}

class Edge implements Comparable<Edge>{
	int peso, origem, destino;
	public Edge(int origem, int destino, int peso){
		this.peso = peso;
		this.origem = origem;
		this.destino = destino;
	}
	@Override
	public int compareTo(Edge aux){
		return this.peso - aux.peso;
	}
} 

class Edge2{
	int peso, destino;
	public Edge2(int destino, int peso){
		this.destino = destino;
		this.peso = peso;
	}
}

class Node implements Comparator<Node>{
	public int node;
	public int cost;
	public Node(){
		//vazio msm
	}
	public Node(int node, int cost){
		this.node = node;
		this.cost = cost;
	}
	public int compare(Node n1, Node n2){
		if(n1.cost < n2.cost){
			return -1;
		}
		if (n1.cost > n2.cost){
			return 1;
		}
		return 0;
	}
}

class In{
	Scanner in;
	In(File in){
		try {
			this.in = new Scanner(in);
		}catch(FileNotFoundException e){

		}
	}

	int readInt(){
		//System.out.println(in.next());
		return in.nextInt();
	}
}

public class Graph
{
	static final Integer INF = 1000000000;
	static final Integer NIL = -1;	 
	private final int V;		// number of vertices
	private int E;	// number of edges
	private Vector<Vector<Integer>> adj;	// adjacency lists
	private Vector<VertexAttributes> atribs;
	Edge[] edges;
	private LinkedList<Integer> adj2[];
	static final int INF2 = 99999;
	private LinkedList<Edge2>[] Lista;
	private int dist[];
	private Set<Integer> settled;
	private PriorityQueue<Node> pq;
	List<List<Node>> adj3;
	private static String filepath = "nada";
	private static int file_vertices = 0, file_arestas = 0;
	private int matrizinha[][];

	public Graph(int V){
		this.V = V; 
		this.E = 0;
		adj = new Vector<Vector<Integer>>(V);	// Create array of lists.
		for (int v = 0; v < V; v++)
			adj.add(new Vector<Integer>());		// Initialize all lists to empty.
		atribs = new Vector<VertexAttributes>(V);
		for (int v = 0; v < V; v++)
			atribs.add(new VertexAttributes());
	}
	public Graph(int V, int E){
		this.V = V;
		this.E = E;
		edges = new Edge[E];
	}
	public Graph(In in){
		this(in.readInt());		//Read V and construct this graph.
		int E = in.readInt();	// Read E.	
		for (int i = 0; i < E; i++)	{ // Add an edge.
			int v = in.readInt();		// Read a vertex,
			int w = in.readInt();		// read another vertex,
			addEdge(v, w);	// and add edge connecting them.
		}
	}
	public @SuppressWarnings("unchecked") Graph(int V, Boolean x){
		this.V = V;
		adj2 = new LinkedList[V];
		for(int i=0;i<V;i++){
			adj2[i] = new LinkedList(); 
		}
	}
	public Graph(int V, String x){
		this.V = V;
		dist = new int[V];
		settled = new HashSet<Integer>();
		pq = new PriorityQueue<Node>(V, new Node());
		matrizinha = new int[V][V];
	}
	public int V(){
		return V;
	}
	public int E(){
		return E;
	}
	public void addEdge(int v, int w){
		adj.get(v).add(w);	// Add w to v’s list.
		adj.get(w).add(v);	// Add v to w’s list.
		E++;
	}
	public Iterable<Integer> adj(int v){
		return adj.get(v);
	}
	public String toString(){
		String s = V + " vertices, " + E + " edges\n";
		for (int v = 0; v < V; v++){
			s += v + ": ";
			for (int w : this.adj(v))
				s += w + " ";
			s += "\n";
		}
		return s;
	}

	public String StatusAtribs(){
		String s = "Vertex Attributes Status (color, pred, d, f) \n";
		int i=0;
		for(VertexAttributes a: atribs){
			s += (i) + ": " + a.color + ", " + a.pred + ", " + a.d + ", " +  a.f;
			s += "\n";
			i++;
		}
		return s;
	}
	
	//===================================================================================================
	//Busca em Largura
	//===================================================================================================
	public void BFS(int s){
		Queue<Integer> Q;
		for(VertexAttributes a: atribs){
			a.color = Color.WHITE;
			a.d = INF;
			a.pred = NIL;
		}
		atribs.get(s).color = Color.GRAY;
		atribs.get(s).d = 0;
		atribs.get(s).pred = NIL;
		Q = new LinkedList<Integer>();
		Q.add(s);
		while (Q.peek() != null){ //if Q is empty, peek() returns null
			int u = Q.poll();
			for(Integer v: adj(u)){
				if (atribs.get(v).color == Color.WHITE){
					atribs.get(v).color = Color.GRAY;
					atribs.get(v).d = atribs.get(u).d + 1;
					atribs.get(v).pred = u;
					Q.add(v);
				}
			}
			atribs.get(u).color =Color.BLACK;
		}
	}
	
	//===================================================================================================
	//Busca em Profundidade
	//===================================================================================================
	public void DFSUtil(int v, boolean visitado[]){
		visitado[v] = true;
		System.out.print(v + " ");
		Iterator<Integer> i = adj2[v].listIterator();
		while(i.hasNext()){
			int n = i.next();
			if (!visitado[n]){
				DFSUtil(n, visitado);
			}
		}
	}
	public void addEdge2(int v, int w){
		adj2[v].add(w);
	}
	public void DFS(int v){
		boolean visitado[] = new boolean[V];
		DFSUtil(v, visitado);
	}

	//===================================================================================================
	//Ordenação Topológica
	//===================================================================================================
	public void TopologicaUtil(int v, boolean visitado[], Stack pilha){
		visitado[v] = true;
		Integer i;
		Iterator<Integer> it = adj2[v].iterator();
		while(it.hasNext()){
			i = it.next();
			if(!visitado[i]){
				TopologicaUtil(i, visitado, pilha);
			}
		}
		pilha.push(new Integer(v));
	}
	public void Topologica(){
		Stack pilha = new Stack();
		boolean visitado[] = new boolean[V];
		for (int i=0;i<V;i++){
			visitado[i] = false;
		}
		for (int i=0;i<V;i++){
			if (visitado[i] == false){
				TopologicaUtil(i, visitado, pilha);
			}
		}
		while (pilha.empty() == false){
			System.out.print(pilha.pop() + " ");
		}
	}

	//===================================================================================================
	//Arvore geradora minima Kruskal
	//===================================================================================================
	public int procure(int[] parent, int i){
		if (parent[i] == -1){
			return i;
		}
		return procure(parent, parent[i]);
	}
	public void uniao(int[] parent, int x, int y){
		int xset = procure(parent, x);
		int yset = procure(parent, y);
		parent[xset] = yset;
	}
	public void AGM_Kruskal(){
		Edge[] resultado = new Edge[V - 1];
		int e = 0;
		int i = 0;
		Arrays.sort(edges);
		int[] parent = new int[V];
		Arrays.fill(parent, -1);
		while(e < V-1 && i < edges.length){
			if(edges[i] == null){
				i++;
				continue;
			}
			Edge proximo_edge = edges[i++];
			int x = procure(parent, proximo_edge.origem);
			int y = procure(parent, proximo_edge.destino);
			if (x!=y){
				resultado[e++] = proximo_edge;
				uniao(parent, x, y);
			}
		}
		System.out.println("Edges na AGM_Kruskal:");
		for (i=0;i<e;i++){
			System.out.println(resultado[i].origem + "-" + resultado[i].destino + ":" + resultado[i].peso);
		}
	}
	//===================================================================================================
	//Arvore geradora minima Prim
	//===================================================================================================
	public int chaveminima(int[] chave, Boolean[] AGMSet){
		int min = Integer.MAX_VALUE, min_index = -1;
		for(int v=0;v<V;v++){
			if(AGMSet[v] == false && chave[v] < min){
				min = chave[v];
				min_index = v;
			}
		}
		return min_index;
	}
	public void AGM_Prim(int graph[][]){
		int[] parent = new int[V];
		int[] chave = new int[V];
		Boolean[] AGMSet = new Boolean[V];
		for (int i=0; i<V; i++){
			chave[i] = Integer.MAX_VALUE;
			AGMSet[i] = false;
		}
		chave[0] = 0;
		parent[0] = -1;
		for(int count = 0; count < V-1; count++){
			int u = chaveminima(chave, AGMSet);
			AGMSet[u] = true;
			for(int v = 0; v < V; v++){
				if(graph[u][v] != 0 && AGMSet[v] == false && graph[u][v] < chave[v]){
					parent[v] = u;
					chave[v] = graph[u][v];
				}
			}
		}
		System.out.println("Edges na AGM_Prim:");
		for(int i=1;i<V;i++){
			System.out.println(parent[i] + "-" + i + ":" + graph[i][parent[i]]);
		}
	}
	//===================================================================================================
	//Caminho minimo Bellman
	//===================================================================================================
	public static int[] Caminho_minimo_Bellman(int V, int[][] edges, int origem){ //lista (O(E + V) espaço memoria?)
		int[] distancia = new int[V];
		Arrays.fill(distancia, (int)1e8);
		distancia[origem] = 0;
		for(int i=0;i<V-1; i++){
			for(int[] edge : edges){
				int u = edge[0];
				int v = edge[1];
				int wt = edge[2];
				if (distancia[u] != 1e8 && distancia[u] + wt < distancia[v]){
					if (i == V - 1){
						return new int[]{-1};
					}
					distancia[v] = distancia[u] + wt;
				}
			}
		}
		return distancia;
	}
	//===================================================================================================
	public static int[] Caminho_minimo_Bellman_2(int V, int[][] matriz, int origem){ // matriz (O(V^2) espaço memória?)
		int[] distancia = new int[V];
		Arrays.fill(distancia, (int)1e8);
		distancia[origem-1] = 0;
			for(int u=0;u<V-1;u++){
				for(int v=0;v<V;v++){
					if(distancia[u] != 1e8 && distancia[u] + matriz[u][v] < distancia[v]){
						distancia[v] = distancia[u] + matriz[u][v];
					}
				}
			}
		
		return distancia;	
	}

	//===================================================================================================
	//Caminho minimo Djkstra
	//===================================================================================================

	public void vizinho(int u){
		int distancia_edge = -1;
		int nova_distancia = -1;
		for (int i=0;i<adj3.get(u).size();i++){
			Node n = adj3.get(u).get(i);
			if(!settled.contains(n.node)){
				distancia_edge = n.cost;
				nova_distancia = dist[u] + distancia_edge;
				if(nova_distancia<dist[n.node]){
					dist[n.node] = nova_distancia;
				}
				pq.add(new Node(n.node, dist[n.node]));
			}
		}
	}

	public void Caminho_minimo_Djkstra(List<List<Node> > adjacente, int origem){
		this.adj3 = adjacente;
		for(int i=0;i<V;i++){
			dist[i] = Integer.MAX_VALUE;
		}
		pq.add(new Node(origem, 0));
		dist[origem] = 0;
		while(settled.size()!=V){
			if (pq.isEmpty()){
				return;
			}
			int u = pq.remove().node;
			if(settled.contains(u)){
				continue;
			}
			settled.add(u);
			vizinho(u);
		}

	}
	//===================================================================================================
	public void addEdge3(int origem, int destino, int peso){
		matrizinha[origem][destino] = peso;
	}
	public int verticeminimo(boolean[] spt, int[] distancia){
		int chaveminima = Integer.MAX_VALUE;
		int vertex = -1;
		for(int i=0; i<V; i++){
			if(spt[i]==false && chaveminima>distancia[i]){
				chaveminima=distancia[i];
				vertex = i;
			}
		}
		return vertex;
	}

	public void Caminho_minimo_Djkstra_2(int origem){
		boolean[] spt = new boolean[V];
		int[] distancia = new int[V];
		for(int i =0; i<V; i++){
			distancia[i] = Integer.MAX_VALUE;
		}
		distancia[origem] = 0;
		for(int i=0;i<V;i++){
			int verticeU = verticeminimo(spt, distancia);
			if(verticeU==-1){
				//System.out.println("Nada ");
				break;
			}
			spt[verticeU] = true;
			for(int verticeV=0;verticeV<V;verticeV++){
				if(matrizinha[verticeU][verticeV]>0){
					if(spt[verticeV]==false && matrizinha[verticeU][verticeV]!=Integer.MAX_VALUE){
						int novachave = matrizinha[verticeU][verticeV] + distancia[verticeU];
						if(novachave<distancia[verticeV]){
							distancia[verticeV] = novachave;
						}
					}
				}
			}
		}
		for (int i=0;i<V;i++){
			System.out.println(origem + "-> " + i +" é "+distancia[i]);
		}
	}



	//===================================================================================================
	//Caminho minimo entre todos os pares
	//===================================================================================================

	public void Caminho_minimo_pares_Floyd(int distancia[][]){
		int i,j,k;
		for(k=0;k<V;k++){
			for(i=0;i<V;i++){
				for(j=0;j<V;j++){
					if (distancia[i][k] + distancia[k][j] < distancia[i][j]){
						distancia[i][j] = distancia[i][k] + distancia[k][j];
					}
				}
			}
		}
		System.out.println("Caminho minimo: ");
		for(i=0;i<V;i++){
			for(j=0;j<V;j++){
				if(distancia[i][j] == INF2){
					System.out.print("INF ");
				}
				else{
					System.out.print(distancia[i][j] + "   ");
				}
			}
			System.out.println(" ");
		}
	}

	//===================================================================================================
	//Fluxo máximo entre redes
	//===================================================================================================
	public boolean fluxoUtil(int rGraph[][], int s, int t, int[] parent){
		boolean visitado[] = new boolean[V];
		for(int i=0;i<V;i++){
			visitado[i] = false;
		}
		LinkedList<Integer> queue = new LinkedList<Integer>();
		queue.add(s);
		visitado[s] = true;
		parent[s] = -1;
		while(queue.size() != 0){
			int u = queue.poll();
			for (int v = 0; v < V; v++) {
                if (visitado[v] == false && rGraph[u][v] > 0) {
                    if (v == t) {
                        parent[v] = u;
                        return true;
                    }
                    queue.add(v);
                    parent[v] = u;
                    visitado[v] = true;
                }
            }
		}
		return false;
	}
	public void fluxomaximo(int graph[][], int s, int t){
		int u,v;
		int rGraph[][] = new int[V][V];
		for(u=0;u<V;u++){
			for(v=0;v<V;v++){
				rGraph[u][v] = graph[u][v];
			}
		}
		int parent[] = new int[V];
		int max_flow = 0;
		while(fluxoUtil(rGraph, s, t, parent)){
			int path_flow = Integer.MAX_VALUE;
			for(v=t;v!=s;v=parent[v]){
				u = parent[v];
				path_flow = Math.min(path_flow, rGraph[u][v]);
			}
			for(v=t; v!=s; v=parent[v]){
				u = parent[v];
				rGraph[u][v] -= path_flow;
                rGraph[v][u] += path_flow;
			}
			max_flow += path_flow; 
		}
		System.out.println("Fluxo máximo: " + max_flow);
	}
	public static void main(String[] args){
		String inicializar;
		System.out.println("\n\n\n\n\n\n\n\n\n\n_________ _______  _______             _______  _______  _______  _______  _______  _______ \n\\__   __/(  ____ )/ ___   )           (  ____ \\(  ____ )(  ___  )(  ____ \\(  ___  )(  ____ \\\n   ) (   | (    )|\\/   )  |           | (    \\/| (    )|| (   ) || (    \\/| (   ) || (    \\/\n   | |   | (____)|    /   )   _____   | |      | (____)|| (___) || (__    | |   | || (_____ \n   | |   |  _____)  _/   /   (_____)  | | ____ |     __)|  ___  ||  __)   | |   | |(_____  )\n   | |   | (       /   _/             | | \\_  )| (\\ (   | (   ) || (      | |   | |      ) |\n   | |   | )      (   (__/\\           | (___) || ) \\ \\__| )   ( || )      | (___) |/\\____) |\n   )_(   |/       \\_______/           (_______)|/   \\__/|/     \\||/       (_______)\\_______)\n\nDigite algo para inicializar: ");
		Scanner scanner = new Scanner(System.in);
		inicializar = scanner.nextLine();
		int execucoes = 10; //numero de execuções pro experimento (default 10)
		int op=1;
		Graph g;
		double densidade = 0.0;
		double TempoInicio = 0, TempoFim = 0;
		double Tempo_Total=0;
		double[] Tempo_BFS=new double[execucoes], Tempo_DFS=new double[execucoes], Tempo_Topologica=new double[execucoes], Tempo_AGM_Kruskal=new double[execucoes], Tempo_AGM_Prim=new double[execucoes], Tempo_Caminho_Bellman=new double[execucoes], Tempo_Caminho_Bellman2=new double[execucoes],Tempo_Djkstra=new double[execucoes], Tempo_Djkstra2=new double[execucoes],Tempo_Floyd=new double[execucoes], Tempo_Ford=new double[execucoes];
		//Tempo_BFS=Tempo_DFS=Tempo_Topologica=Tempo_AGM_Kruskal=Tempo_AGM_Prim=Tempo_Caminho_Bellman=Tempo_Djkstra=Tempo_Floyd=Tempo_Ford=new double[execucoes];
		while (op!=0){
			System.out.println("|==============================Menu==============================|\n|0 - Sair\t\t\t\t\t\t\t |\n|1 - Busca em Largura (BFS)\t\t\t\t\t |\n|2 - Busca em Profundidade (DFS)\t\t\t\t |\n|3 - Ordenação Topológica\t\t\t\t\t |\n|4 - Árvore Geradora Mínima (Kruskal)\t\t\t\t |\n|5 - Árvore Geradora Mínima (Prim)\t\t\t\t |\n|6 - Caminho mínimo de origem única (Bellman-Ford)\t\t |\n|7 - Caminho mínimo de origem única (Dijkstra)\t\t\t |\n|8 - Caminho mínimo entre todos os pares (Floyd-Warshall)\t |\n|9 - Fluxo máximo entre redes (Ford-Fulkerson)\t\t\t |\n|10 - Mudar arquivo teste\t\t\t\t\t |\n|11 - Sobreescrever arquivo de tempo de execução\t\t |\n|================================================================|\nEscolha uma opção:");
			op = scanner.nextInt();
			
			switch(op){
				case 0:
					System.out.println("Saindo...");
				break;
				case 1: //Busca em Largura (BFS)
					//==============================================================================
					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_BFS[exe] = 0;
					}
					//Tempo_BFS = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(0); // 															BFS (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									g = new Graph(file_vertices + 1); //								BFS
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2 " : " + criagrafo3);
									g.addEdge(criagrafo1, criagrafo2);//								BFS
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						g.BFS(1); // 																	BFS
						System.out.println(g.StatusAtribs()); // 										BFS
						TempoFim = System.nanoTime();
						Tempo_BFS[exe] = Tempo_BFS[exe] + (TempoFim - TempoInicio);  // 							BFS
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_BFS[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_BFS[exe]/1000000000) + " segundos");
					}
					
					System.out.println("Tempo BFS(total): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo BFS(media): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
				break;
				case 2: //Busca em Profundidade (DFS)
					//==============================================================================
					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_DFS[exe] = 0;
					}
					//Tempo_DFS = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(4, false); // 												DFS (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									g = new Graph(file_vertices + 1, false); //						DFS
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2);
									g.addEdge2(criagrafo1, criagrafo2);//								DFS
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						g.DFS(1); //começando do 1 													DFS
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_DFS[exe] = Tempo_DFS[exe] + (TempoFim - TempoInicio); // 					DFS
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_DFS[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_DFS[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo DFS(total): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo DFS(media): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
				break;
				
				case 3: //Ordenação Topológica
					//==============================================================================
					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_Topologica[exe] = 0;
					}
					//Tempo_Topologica = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(6, false); // 												Ordenação Topológica (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									g = new Graph(file_vertices + 1, false); //						Ordenação Topológica
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2);
									g.addEdge2(criagrafo1, criagrafo2);//								Ordenação Topológica
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						g.Topologica();//	 															Ordenação Topológica
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_Topologica[exe] = Tempo_Topologica[exe] + (TempoFim - TempoInicio); // 				Ordenação Topológica
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_Topologica[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_Topologica[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo Topologica(total): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total / execucoes;
					System.out.println("Tempo Topologica(media): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
				break;
				case 4: //Árvore Geradora Mínima (Kruskal)
					//==============================================================================
					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_AGM_Kruskal[exe] = 0;
					}
					//Tempo_AGM_Kruskal = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						int edgeIndex=0; // 															Árvore Geradora Mínima (Kruskal)
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(4, 5); // 													Árvore Geradora Mínima (Kruskal)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									g = new Graph(file_vertices + 1, file_arestas); //					Árvore Geradora Mínima (Kruskal)
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
								}
								if (line.startsWith("a")) {
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									if (edgeIndex < file_arestas) { // 									Árvore Geradora Mínima (Kruskal)
										g.edges[edgeIndex++] = new Edge(criagrafo1, criagrafo2, criagrafo3); //Árvore Geradora Mínima (Kruskal)
									} else {// 															Árvore Geradora Mínima (Kruskal)
										System.err.println("Número de arestas ERRO: " + file_arestas);//Árvore Geradora Mínima (Kruskal)
										break;// 														Árvore Geradora Mínima (Kruskal)
									}
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						g.AGM_Kruskal();//	 															Árvore Geradora Mínima (Kruskal)
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_AGM_Kruskal[exe] = Tempo_AGM_Kruskal[exe] + (TempoFim - TempoInicio); // 			Árvore Geradora Mínima (Kruskal)
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_AGM_Kruskal[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_AGM_Kruskal[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo AGM_Kruskal(total): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo AGM_Kruskal(media): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
				break;
				case 5: //Árvore Geradora Mínima (Prim)
					//==============================================================================
					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_AGM_Prim[exe] = 0;
					}
					//Tempo_AGM_Prim = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						int grapho[][] = new int[1][1];// 												AGM(Prim)
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(1); // 															AGM(Prim) (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									grapho = new int[file_vertices+1][file_vertices+1];
									g = new Graph(file_vertices + 1); //								AGM(Prim)
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2 + ":" + criagrafo3);
									grapho[criagrafo1-1][criagrafo2-1] = criagrafo3;// 					AGM(Prim)
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						g.AGM_Prim(grapho);//	 														AGM(Prim)
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_AGM_Prim[exe] = Tempo_AGM_Prim[exe] + (TempoFim - TempoInicio); // 					AGM(Prim)
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_AGM_Prim[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_AGM_Prim[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo AGM_Prim(total): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo AGM_Prim(media): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
				break;
				case 6: //Caminho mínimo de origem única (Bellman-Ford)
					//==============================================================================
					//matriz
					//==============================================================================
					
					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_Caminho_Bellman2[exe] = 0;
					}
					//Tempo_Caminho_Bellman = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						int matriz[][] = new int[1][1];// 												Bellman-Ford
						int origem = 1; //nó inicial de busca											Bellman-Ford
						int j1=0,j2=0;
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(1); // 															Bellman-Ford (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									matriz = new int[file_vertices+1][file_vertices+1];
									for(int i=0; i<file_vertices;i++){
										for(int i2=0; i2<file_vertices;i2++){
											matriz[i][i2] = (int) 1e8;
										}
									}
									g = new Graph(file_vertices + 1); //								Bellman-Ford
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2 + ":" + criagrafo3);
									matriz[criagrafo1-1][criagrafo2-1] = criagrafo3;
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						int[] resposta = Caminho_minimo_Bellman_2(file_vertices+1, matriz, origem);//	 	Bellman-Ford
						for (int distancia : resposta){
							System.out.print(distancia + " ");
						}
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_Caminho_Bellman2[exe] = Tempo_Caminho_Bellman2[exe] + TempoFim - TempoInicio; // 								Bellman-Ford
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_Caminho_Bellman2[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_Caminho_Bellman[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo_Caminho_Bellman(total)(matriz): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo_Caminho_Bellman(media)(matriz): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
					//lista
					//==============================================================================

					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_Caminho_Bellman[exe] = 0;
					}
					//Tempo_Caminho_Bellman = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						int edges[][] = new int[1][1];// 												Bellman-Ford
						int origem = 1; //nó inicial de busca											Bellman-Ford
						int j1=0,j2=0;
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(1); // 															Bellman-Ford (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									edges = new int[file_arestas][3];
									g = new Graph(file_vertices + 1); //								Bellman-Ford
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2 + ":" + criagrafo3);
									edges[j1][0] = criagrafo1;
									edges[j1][1] = criagrafo2;
									edges[j1][2] = criagrafo3;
									j1++;
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						int[] resposta = Caminho_minimo_Bellman(file_vertices+1, edges, origem);//	 	Bellman-Ford
						for (int distancia : resposta){
							System.out.print(distancia + " ");
						}
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_Caminho_Bellman[exe] = Tempo_Caminho_Bellman[exe] + TempoFim - TempoInicio; // 								Bellman-Ford
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_Caminho_Bellman[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_Caminho_Bellman[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo_Caminho_Bellman(total)(lista): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo_Caminho_Bellman(media)(lista): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					
					//==============================================================================
				break;
				case 7: //Caminho mínimo de origem única (Dijkstra)
					//==============================================================================
					//matriz
					//==============================================================================

					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_Djkstra2[exe] = 0;
					}
					//Tempo_Djkstra = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						List<List<Node>> novoadj = new ArrayList<List<Node>>(); // 					Dijkstra											
						int Origem_Comeco = 1; //nó inicial de busca								Dijkstra
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(1, "algo"); // 											Dijkstra (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									g = new Graph(file_vertices + 1, "algo"); //					Dijkstra
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2 + ":" + criagrafo3);
									g.addEdge3(criagrafo1, criagrafo2, criagrafo3);
									//novoadj.get(criagrafo1).add(new Node(criagrafo2,criagrafo3));
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						g.Caminho_minimo_Djkstra_2(Origem_Comeco);//							Dijkstra
						System.out.println("Caminho minimo: ");
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_Djkstra2[exe] = Tempo_Djkstra2[exe] + (TempoFim - TempoInicio); // 				Dijkstra
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_Djkstra2[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_Djkstra2[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo_Djkstra(total)(matriz): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo_Djkstra(media)(matriz): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
					//lista
					//==============================================================================

					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_Djkstra[exe] = 0;
					}
					//Tempo_Djkstra = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						List<List<Node>> novoadj = new ArrayList<List<Node>>(); // 					Dijkstra											
						int Origem_Comeco = 1; //nó inicial de busca								Dijkstra
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
						} 
						g = new Graph(1, "algo"); // 											Dijkstra (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									g = new Graph(file_vertices + 1, "algo"); //					Dijkstra
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
									for(int i=0;i<file_vertices+1;i++){ //							Dijkstra
										List<Node> item = new ArrayList<Node>(); //					Dijkstra
										novoadj.add(item); //										Dijkstra
									} //															Dijkstra
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2 + ":" + criagrafo3);
									novoadj.get(criagrafo1).add(new Node(criagrafo2,criagrafo3));
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						g.Caminho_minimo_Djkstra(novoadj, Origem_Comeco);//							Dijkstra
						System.out.println("Caminho minimo: ");
						for (int i=0;i<g.dist.length;i++){
							System.out.println(Origem_Comeco + "-> " + i + " é " + g.dist[i]);
						}
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_Djkstra[exe] = Tempo_Djkstra[exe] + (TempoFim - TempoInicio); // 				Dijkstra
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_Djkstra[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_Djkstra[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo_Djkstra(total)(lista): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo_Djkstra(media)(lista): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					
					//==============================================================================
				break;
				case 8: //Caminho mínimo entre todos os pares (Floyd-Warshall)
					//==============================================================================
					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_Floyd[exe] = 0;
					}
					//Tempo_Floyd = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						int graphi[][] = new int[1][1]; // 											Floyd
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
							//filepath = "sample5-3.gr";
						} 
						g = new Graph(4); // 														Floyd (só pra inicializar)
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									g = new Graph(file_vertices+1); //								Floyd
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
									graphi = new int[file_vertices+1][file_vertices+1];//			Floyd
									for (int i = 0; i <= file_vertices; i++) {//					Floyd
										for (int j = 0; j <= file_vertices; j++) {//				Floyd
											if(j==i){//												Floyd
												graphi[i][j] = 0;//									Floyd
											}//														Floyd
											else{//													Floyd
												graphi[i][j] = INF2;//								Floyd
											}//														Floyd
										}//															Floyd
									}//																Floyd
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2 + ":" + criagrafo3);
									graphi[criagrafo1-1][criagrafo2-1] = criagrafo3;//				Floyd
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						System.out.println("Vertices: "+ file_vertices);
						g.Caminho_minimo_pares_Floyd(graphi); // 									Floyd
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_Floyd[exe] = Tempo_Floyd[exe] + (TempoFim - TempoInicio); // 					Floyd
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_Floyd[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_Floyd[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo Floyd(total): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo Floyd(media): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
				break;
				case 9: //Fluxo máximo entre redes (Ford-Fulkerson)
					//==============================================================================
					Tempo_Total = 0;
					for (int exe=0; exe<execucoes;exe++){
						Tempo_Ford[exe] = 0;
					}
					//Tempo_Ford = 0;
					for(int exe=0; exe<execucoes;exe++){
						System.out.println("Execução: " + (exe+1));
						if (filepath == "nada"){
							System.out.println("Escolha um arquivo para testar primeiro (Opção 10)...");
							break;
							//filepath = "sample5-3.gr";
						} 
						g = new Graph(1); // 															Ford (só pra inicializar)
						int graphu[][] = new int[1][1];
						TempoInicio = System.nanoTime();
						try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
							String line;
							while ((line = br.readLine()) != null) {
								if (line.startsWith("p")) {
									String[] parts = line.split("\\s+");
									file_vertices = Integer.parseInt(parts[2]);
									file_arestas = Integer.parseInt(parts[3]);
									graphu = new int[file_vertices+1][file_vertices+1];
									g = new Graph(file_vertices + 1); //								Ford
									densidade = (double)file_arestas/(file_vertices*(file_vertices-1));
									for (int i = 0; i <= file_vertices; i++) {//						Ford
										for (int j = 0; j <= file_vertices; j++) {//					Ford
											graphu[i][j] = 0;//											Ford
										}//																Ford
									}//																	Ford
								}
								if (line.startsWith("a")){
									String[] parts = line.split("\\s+");
									int criagrafo1 = Integer.parseInt(parts[1]);
									int criagrafo2 = Integer.parseInt(parts[2]);
									int criagrafo3 = Integer.parseInt(parts[3]);
									//System.out.println(criagrafo1 + "->" + criagrafo2);
									graphu[criagrafo1][criagrafo2] = criagrafo3;//						Ford
								}
							}
						} catch (IOException e) {
							System.err.println("Erro ao ler o arquivo: " + e.getMessage());
						}
						g.fluxomaximo(graphu, 1, 100); //fluxo entre 1 e 100 						Ford
						System.out.println(" ");
						TempoFim = System.nanoTime();
						Tempo_Ford[exe] = Tempo_Ford[exe] + (TempoFim - TempoInicio); // 							Ford
					}
					for(int exe=0;exe<execucoes;exe++){
						Tempo_Total = Tempo_Total + Tempo_Ford[exe];
						System.out.println((exe+1) + ":" + String.format("%.10f",Tempo_Ford[exe]/1000000000) + " segundos");
					}
					System.out.println("Vertices: "+ file_vertices);
					System.out.println("Arestas: "+ file_arestas);
					System.out.println("Densidade: "+ densidade);
					System.out.println("Tempo Ford(total): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					Tempo_Total = Tempo_Total/execucoes;
					System.out.println("Tempo Ford(media): " + String.format("%.10f", Tempo_Total / 1000000000) + " segundos");
					//==============================================================================
				break;
				case 10:
				System.out.println("|==========Menu==========|\n|1 -  sample100-1980.gr  |\n|2 -  sample100-3960.gr  |\n|3 -  sample100-5940.gr  |\n|4 -  sample100-7920.gr  |\n|5 -  sample100-9900.gr  |\n|6 -  sample200-7960.gr  |\n|7 -  sample200-15920.gr |\n|8 -  sample200-23880.gr |\n|9 -  sample200-31840.gr |\n|10 - sample200-39800.gr |\n|11 - sample500-49900.gr |\n|12 - sample500-99800.gr |\n|13 - sample500-149700.gr|\n|14 - sample500-199600.gr|\n|15 - sample500-249500.gr|\n|========================|\nEscolha uma opção:");
				int menu_file = scanner.nextInt();
				switch(menu_file){
					case 1: filepath = "sample100-1980.gr"; break;
					case 2: filepath = "sample100-3960.gr"; break;
					case 3: filepath = "sample100-5940.gr"; break;
					case 4: filepath = "sample100-7920.gr"; break;
					case 5: filepath = "sample100-9900.gr"; break;
					case 6: filepath = "sample200-7960.gr"; break;
					case 7: filepath = "sample200-15920.gr"; break;
					case 8: filepath = "sample200-23880.gr"; break;
					case 9: filepath = "sample200-31840.gr"; break;
					case 10: filepath = "sample200-39800.gr"; break;
					case 11: filepath = "sample500-49900.gr"; break;
					case 12: filepath = "sample500-99800.gr"; break;
					case 13: filepath = "sample500-149700.gr"; break;
					case 14: filepath = "sample500-199600.gr"; break;
					case 15: filepath = "sample500-249500.gr"; break;
					default: System.out.println("Opção Inválida..."); break;
				}
				break;
				case 11:
					try (FileWriter writer = new FileWriter("tempo_execucao.txt", true)) {
						Tempo_Total = 0;
						writer.write("Tempo BFS:\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_BFS[exe];
							writer.write(Tempo_BFS[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo DFS:\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_DFS[exe];
							writer.write(Tempo_DFS[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo Topologica:\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_Topologica[exe];
							writer.write(Tempo_Topologica[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo AGM Kruskal:\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_AGM_Kruskal[exe];
							writer.write(Tempo_AGM_Kruskal[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo AGM Prim:\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_AGM_Prim[exe];
							writer.write(Tempo_AGM_Prim[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo Bellman(lista):\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_Caminho_Bellman[exe];
							writer.write(Tempo_Caminho_Bellman[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo Bellman(matriz):\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_Caminho_Bellman2[exe];
							writer.write(Tempo_Caminho_Bellman2[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo Djkstra(lista):\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_Djkstra[exe];
							writer.write(Tempo_Djkstra[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo Djkstra(matriz):\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_Djkstra2[exe];
							writer.write(Tempo_Djkstra2[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo Floyd:\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_Floyd[exe];
							writer.write(Tempo_Floyd[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						//=============================================================================================
						Tempo_Total = 0;
						writer.write("\nTempo Fluxo:\n");
						for(int exe=0; exe<execucoes; exe++){
							Tempo_Total = Tempo_Total + Tempo_Ford[exe];
							writer.write(Tempo_Ford[exe]/1000000000+"\n");
						}
						writer.write("Tempo Total: " + Tempo_Total/1000000000);
						Tempo_Total = Tempo_Total/execucoes;
						writer.write("\nTempo Medio: " + Tempo_Total/1000000000);
						writer.write(System.lineSeparator());
						System.out.println("Tempo salvo no arquivo com sucesso");
					}catch (IOException e){
						System.out.println("Ocorreu um erro ao adicionar texto ao arquivo");
					}
				break;

				default:
					System.out.println("Opção Inválida...");
				break;
			}		
	}
	scanner.close();
}
}
