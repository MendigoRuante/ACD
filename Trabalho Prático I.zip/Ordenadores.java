import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
public class Ordenadores{ //isertion, merge, bubble, selection, shell, heap, quick, counting, radix, bucket

    public static <T extends Comparable<T>> void InsertionSort(T[] A, int n){
        int i;
        int j;
        T chave;

        for (i=0; i<n;i++){
            chave = A[i];
            j= i - 1;
            while(j>=0 && A[j].compareTo(chave) > 0){
                A[j+1] = A[j];
                j = j - 1;
            }
            A[j+1] = chave;
        }
    }

    public static <T extends Comparable<T>> void MergeSort(T[] A, int p, int r){
        if (p >= r){
            return;
        }
        int q = (p+r)/2;
        MergeSort(A, p, q);
        MergeSort(A, q+1, r);
        Merge(A, p, q, r);
    }

    public static <T extends Comparable<T>> void Merge(T[] A, int p, int q, int r){
        int nl = q - p + 1;
        int nr = r - q;
        int i;
        int j;
        int k;
        T[] L = (T[]) new Comparable[nl];
        T[] R = (T[]) new Comparable[nr];
        for (i=0;i<=nl-1;i++){
            L[i] = A[p+i];
        }
        for (j=0;j<=nr-1;j++){
            R[j] = A[q+j+1];
        }
        i=0;
        j=0;
        k=p;
        while (i < nl && j < nr) {
            if (L[i].compareTo(R[j]) <= 0) {
                A[k] = L[i];
                i++;
            } else {
                A[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < nl) {
            A[k] = L[i];
            i++;
            k++;
        }

        while (j < nr) {
            A[k] = R[j];
            j++;
            k++;
        }
    }

    public static <T extends Comparable<T>> void BubbleSort(T[] A, int n){
        int i;
        int j;
        T aux = null;

        for(i=0;i<n-1;i++){
            for(j=0;j<n-i-1;j++){ 
                if (A[j].compareTo(A[j + 1]) > 0){
                    aux = A[j];
                    A[j] = A[j+1];
                    A[j+1] = aux;
                }
            }
        }
    }

    public static <T extends Comparable<T>> void SelectionSort(T[] A, int n){
        int i;
        int menor;
        int j;
        T aux;

        for(i=0;i<n;i++){
            menor = i;
            for(j=i+1;j<n;j++){
                if(A[j].compareTo(A[menor]) < 0){
                    menor = j;
                }
            }
            aux = A[i];
            A[i] = A[menor];
            A[menor] = aux;
        }
    }

    public static <T extends Comparable<T>> void ShellSort(T[] A, int n){
        int h;
        int i;
        int j;
        T x;

        h=1;
        do{
            h=h*3+1;
        }while(h<n);
        do{
        h=h/3;
        for(i=h;i<n;i++){
                x = A[i];
                j = i;
                while (j >= h && A[j - h].compareTo(x) > 0) {
                    A[j] = A[j - h];
                    j = j - h;
                }
                A[j] = x;
        }
        }while(h!=1);
    }

    public static <T extends Comparable<T>> void HeapSort(T[] A, int tamanhoDoHeap) {

        constroiMaxHeap(A, tamanhoDoHeap);

        for (int i = tamanhoDoHeap - 1; i > 0; i--) {
            T aux = A[0];
            A[0] = A[i];
            A[i] = aux;

            tamanhoDoHeap--;
            maximizaHeap(A, 0, tamanhoDoHeap);
        }
    }

    private static <T extends Comparable<T>> void constroiMaxHeap(T[] A, int tamanhoDoHeap) {
        for (int i = (tamanhoDoHeap / 2) - 1; i >= 0; i--) {
            maximizaHeap(A, i, tamanhoDoHeap);
        }
    }

    private static <T extends Comparable<T>> void maximizaHeap(T[] A, int i, int tamanhoDoHeap) {
        int maior = i;
        int l = esquerda(i);
        int r = direita(i);

        if (l < tamanhoDoHeap && A[l].compareTo(A[maior]) > 0) {
            maior = l;
        }
        if (r < tamanhoDoHeap && A[r].compareTo(A[maior]) > 0) {
            maior = r;
        }
        
        if (maior != i) {
            T temp = A[i];
            A[i] = A[maior];
            A[maior] = temp;
            maximizaHeap(A, maior, tamanhoDoHeap);
        }
    }

    private static int esquerda(int i) {
        return 2 * i + 1;
    }

    private static int direita(int i) {
        return 2 * i + 2;
    }

    public static <T extends Comparable<T>> void QuickSort(T[] A, int p, int r) {
        if (p < r) {
            T x = A[r];
            int i = p - 1;
            for (int j = p; j < r; j++) {
                if (A[j].compareTo(x) <= 0) {
                    i++;
                    T aux = A[i];
                    A[i] = A[j];
                    A[j] = aux;
                }
            }
            T temp = A[i + 1];
            A[i + 1] = A[r];
            A[r] = temp;
            int q = i + 1;
            QuickSort(A, p, q - 1);
            QuickSort(A, q + 1, r);
        }
    }

    public static void CountingSort(int n, int k, int[] A, int[] B) {
        int[] C = new int[k + 1];
        int i, j;
    
        for (i = 0; i <= k; i++) {
            C[i] = 0;
        }
    
        for (j = 0; j < n; j++) {
            C[A[j]] = C[A[j]] + 1;
        }
    
        for (i = 1; i <= k; i++) {
            C[i] = C[i] + C[i - 1];
        }
    
        for (j = n - 1; j >= 0; j--) {
            B[C[A[j]] - 1] = A[j];
            C[A[j]] = C[A[j]] - 1;
        }

        for (j = 0; j < n; j++) {
            A[j] = B[j];
        }
    }

    public static void RadixSort(int[] A){
        int max = A[0];
        for (int i = 1; i < A.length; i++) {
            if (A[i] > max) {
                max = A[i];
            }
        }

        for (int exp = 1; max / exp > 0; exp *= 10) {
            int n = A.length;
            int[] output = new int[n];
            int[] count = new int[10];

            for (int i = 0; i < n; i++) {
                int digit = (A[i] / exp) % 10;
                count[digit]++;
            }

            for (int i = 1; i < 10; i++) {
                count[i] += count[i - 1];
            }

            for (int i = n - 1; i >= 0; i--) {
                int digit = (A[i] / exp) % 10;
                output[count[digit] - 1] = A[i];
                count[digit]--;
            }

            System.arraycopy(output, 0, A, 0, n);
        }
    }

    public static void BucketSort(double[] A, int n) {
        double min = A[0];
        double max = A[0];

        for (int i = 1; i < n; i++) {
            if (A[i] < min) min = A[i];
            if (A[i] > max) max = A[i];
        }

        List<List<Double>> B = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            B.add(new ArrayList<>());
        }
    
        for (int i = 0; i < n; i++) {
            double normalizedValue = (A[i] - min) / (max - min);
            
            int index = (int) (n * normalizedValue);
            
            if (index == n) index--;

            B.get(index).add(A[i]);
        }
    
        for (List<Double> balde : B) {
            for (int i = 1; i < balde.size(); i++) {
                double key = balde.get(i);
                int j = i - 1;
                while (j >= 0 && balde.get(j) > key) {
                    balde.set(j + 1, balde.get(j));
                    j = j - 1;
                }
                balde.set(j + 1, key);
            }
        }
        int x = 0;
        for (List<Double> balde : B) {
            for (double valor : balde) {
                A[x++] = valor;
            }
        }
    }


    //========================================================================================================

    public static void InsertionSortint(int[] A, int n) {
        for (int i = 1; i < n; i++) {
            int chave = A[i];
            int j = i - 1;
            while (j >= 0 && A[j] > chave) {
                A[j + 1] = A[j];
                j = j - 1;
            }
            A[j + 1] = chave;
        }
    }
    
    public static void MergeSortint(int[] A, int p, int r) {
        if (p >= r) {
            return;
        }
        int q = (p + r) / 2;
        MergeSortint(A, p, q);
        MergeSortint(A, q + 1, r);
        Mergeint(A, p, q, r);
    }

    public static void Mergeint(int[] A, int p, int q, int r) {
        int nL = q - p + 1;
        int nR = r - q;
        int[] L = new int[nL];
        int[] R = new int[nR];
        for (int i = 0; i < nL; i++) {
            L[i] = A[p + i];
        }
        for (int j = 0; j < nR; j++) {
            R[j] = A[q + 1 + j];
        }
        int i = 0, j = 0, k = p;
        while (i < nL && j < nR) {
            if (L[i] <= R[j]) {
                A[k] = L[i];
                i++;
            } else {
                A[k] = R[j];
                j++;
            }
            k++;
        }
        while (i < nL) {
            A[k] = L[i];
            i++;
            k++;
        }
        while (j < nR) {
            A[k] = R[j];
            j++;
            k++;
        }
    }

    public static void BubbleSortint(int[] A, int n) {
        int aux;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (A[j] > A[j + 1]) {
                    aux = A[j];
                    A[j] = A[j + 1];
                    A[j + 1] = aux;
                }
            }
        }
    }

    public static void SelectionSortint(int[] A, int n) {
        int i;
        int j;
        int menor;
        int aux;
        for (i=0;i<n-1;i++) {
            menor = i;
            for (j=i+1; j<n; j++) {
                if (A[j] < A[menor]) {
                    menor = j;
                }
            }
            aux = A[i];
            A[i] = A[menor];
            A[menor] = aux;
        }
    }

    public static void ShellSortint(int[] A, int n) {
        int h = 1;
        int i;
        int j;
        int x;
        do {
            h=h*3+1;
        } while (h < n / 3);
        do {
            for (i = h; i < n; i++) {
                x = A[i];
                j = i;
                do {
                    if (j>=h && A[j - h]> x) {
                        A[j] = A[j - h];
                        j -= h;
                    }
                } while (j >= h && A[j - h] > x);
                
                A[j] = x;
            }
            h = h / 3;
        } while (h >= 1);
    }
    
    public static void HeapSortint(int[] A, int tamanhoDoHeap) {
        constroiMaxHeapint(A, tamanhoDoHeap); 
        for (int i = tamanhoDoHeap - 1; i > 0; i--) {
            int aux = A[0];
            A[0] = A[i];
            A[i] = aux;
            tamanhoDoHeap--;
            maximizaHeapint(A, 0, tamanhoDoHeap);
        }
    }
    
    private static void constroiMaxHeapint(int[] A, int tamanhoDoHeap) {
        for (int i = (tamanhoDoHeap / 2) - 1; i >= 0; i--) {
            maximizaHeapint(A, i, tamanhoDoHeap);
        }
    }
    
    private static void maximizaHeapint(int[] A, int i, int tamanhoDoHeap) {
        int maior = i;
        int l = esquerdaint(i);
        int r = direitaint(i);
        if (l < tamanhoDoHeap && A[l] > A[maior]) {
            maior = l;
        }
        if (r < tamanhoDoHeap && A[r] > A[maior]) {
            maior = r;
        }
        if (maior != i) {
            int temp = A[i];
            A[i] = A[maior];
            A[maior] = temp;
            maximizaHeapint(A, maior, tamanhoDoHeap);
        }
    }
    
    private static int esquerdaint(int i) {
        return 2 * i + 1;
    }
    
    private static int direitaint(int i) {
        return 2 * i + 2;
    }

    public static void QuickSortint(int[] A, int p, int r) {
        if (p < r) {
            int q = particionaint(A, p, r);
            QuickSortint(A, p, q - 1);
            QuickSortint(A, q + 1, r);
        }
    }
    private static int particionaint(int[] A, int p, int r) {
        int pivot = A[r];
        int i = p - 1;
        for (int j = p; j < r; j++) {
            if (A[j] <= pivot) {
                i++;
                int temp = A[i];
                A[i] = A[j];
                A[j] = temp;
            }
        }
        int temp = A[i + 1];
        A[i + 1] = A[r];
        A[r] = temp;
        return i + 1;
    }


}