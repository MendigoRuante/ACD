import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;
public class Main{
    public static void main(String[] args){
        Random rand = new Random();
        //Vetores testes:
        //1 Com elementos em ordem crescente
        Integer[] V1 = new Integer[]{1,2,3,4,5,6,7,8,9,10};
        
        //1 Com elementos em ordem decrescente
        Integer[] V2 = new Integer[]{10,9,8,7,6,5,4,3,2,1};
        
        //1 Com elementos em gerador aleatório
        Integer[] V3 = new Integer[10];
        for (int i = 0; i < 10 ;i++){
          V3[i] = rand.nextInt(100);
        }

        //1 com varios elementos repetidos
        Integer[] V4 = new Integer[]{1,2,1,2,1,2,1,2,1,2};
        
        int m = 0;
        int n = 0;
        int x = 0;
        int op = 0;
        int op2 = 0;
        int execucoes = 30;
        Scanner scanner = new Scanner(System.in);
        Integer[] vetor = new Integer[x];
        Integer[] InsertionVetor = new Integer[x];
        Integer[] MergeVetor = new Integer[x];
        Integer[] BubbleVetor = new Integer[x];
        Integer[] SelectionVetor = new Integer[x];
        Integer[] ShellVetor = new Integer[x];
        Integer[] HeapVetor = new Integer[x];
        Integer[] QuickVetor = new Integer[x];
        Integer[] CountingVetor = new Integer[x];
        Integer[] VetorAux = new Integer[x];
        Integer[] RadixVetor = new Integer[x];
        Integer[] BucketVetor = new Integer[x];
        Integer[] CopiasTestes = new Integer[x];
        int[] Ordenaint = new int[x];

        //Integer[] vetor; 
        double tempoInicio, tempoFim, tempoExecucao = 0;
        while(m != 5){
            System.out.println("======================");
            System.out.println("Menu: ");
            System.out.println("1 - Criar Vetor Aleatório");
            System.out.println("2 - Ordenar Vetor");
            System.out.println("3 - Testar Vetores");
            System.out.println("4 - Ordenar com int e parametrizado");
            System.out.println("5 - Sair do programa");
            System.out.println("======================\n");
            m = scanner.nextInt();
            switch(m){
                case 1:
                    System.out.println("Informe o tamanho do vetor:  ");
                    System.out.println("1 - 100");
                    System.out.println("2 - 1000");
                    System.out.println("3 - 10000");
                    System.out.println("4 - 100000");
                    System.out.println("5 - 1000000");
                    int entrada = scanner.nextInt();
                    switch(entrada){
                        case 1:
                            x = 100;
                            vetor = new Integer[x];
                            for (int i = 0; i < x ;i++){
                                vetor[i] = rand.nextInt(100);
                                System.out.print(" [" + vetor[i] + "]"); // isso n tem nos outros
                            }
                            System.out.println("\nVetor com " + x + " elementos aleatório criado.");
                            break;
                        case 2:
                            x = 1000;
                            vetor = new Integer[x];
                            for (int i = 0; i < x ;i++){
                                vetor[i] = rand.nextInt(100);
                            }
                            System.out.println("\nVetor com " + x + " elementos aleatório criado.");
                            break;
                        case 3:
                            x = 10000;
                            vetor = new Integer[x];
                            for (int i = 0; i < x ;i++){
                                vetor[i] = rand.nextInt(100);
                            }
                            System.out.println("\nVetor com " + x + " elementos aleatório criado.");
                            break;
                        case 4:
                            x = 100000;
                            vetor = new Integer[x];
                            for (int i = 0; i < x ;i++){
                                vetor[i] = rand.nextInt(100);
                            }
                            System.out.println("\nVetor com " + x + " elementos aleatório criado.");
                            break;
                        case 5:
                            x = 1000000;
                            vetor = new Integer[x];
                            for (int i = 0; i < x ;i++){
                                vetor[i] = rand.nextInt(100);
                            }
                            System.out.println("\nVetor com " + x + " elementos aleatório criado.");
                            break;
                        default:
                            System.out.println("Valor informado inválido.");
                    }
                    break;
                case 2:
                    if(x == 0){
                        System.out.println("Primeiro crie um vetor antes de ordená-lo");
                        break;
                    }
                    else{
                        System.out.println("======================");
                        System.out.println("Informe o método de ordenação a ser utilizado: ");
                        System.out.println("1 - InsertionSort");
                        System.out.println("2 - MergeSort");
                        System.out.println("3 - BubbleSort");
                        System.out.println("4 - SelectionSort");
                        System.out.println("5 - ShellSort");
                        System.out.println("6 - Heapsort");
                        System.out.println("7 - QuickSort");
                        System.out.println("8 - CountingSort");
                        System.out.println("9 - RadixSort");
                        System.out.println("10 - BucketSort");
                        System.out.println("======================");
                        n = scanner.nextInt();
                        switch(n){
                            case 1:
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Insertion Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    InsertionVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, InsertionVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.InsertionSort(InsertionVetor, x);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + InsertionVetor[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            case 2:
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Merge Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    MergeVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, MergeVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.MergeSort(MergeVetor, 0, MergeVetor.length-1);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + MergeVetor[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            case 3:
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Bubble Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    BubbleVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, BubbleVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.BubbleSort(BubbleVetor, x);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + BubbleVetor[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            case 4:
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Selection Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    SelectionVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, SelectionVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.SelectionSort(SelectionVetor, x);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + SelectionVetor[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            case 5:
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Shell Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    ShellVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, ShellVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.ShellSort(ShellVetor, x);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + ShellVetor[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            case 6:
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Heap Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    HeapVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, HeapVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.HeapSort(HeapVetor, x);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + HeapVetor[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            case 7:
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Quick Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    QuickVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, QuickVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.QuickSort(QuickVetor,0,x-1);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + QuickVetor[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            case 8:
                            int[] Countingint = new int[x];
                            for(int i = 0; i < x; i++){
                                Countingint[i] = vetor[i];
                            }
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Counting Sort]");
                            for(int i = 0; i < execucoes; i++){
                                int[] CountingVetor2 = new int[x];
                                tempoInicio = System.nanoTime();
                                Ordenadores.CountingSort(Countingint.length, Arrays.stream(Countingint).max().getAsInt(), Countingint, CountingVetor2);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + Countingint[i] + "]");
                                }
                            System.out.println("\n=======================ORDENADO======================");
                            tempoExecucao = 0;
                            break;
                            case 9:
                                int[] Radixint = new int[x];
                                for(int i = 0; i < x; i++){
                                    Radixint[i] = vetor[i];
                                }
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Radix Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    RadixVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, RadixVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.RadixSort(Radixint);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + Radixint[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            case 10:
                                double[] Bucketdouble = new double[x];
                                for(int i = 0; i < x; i++){
                                    Bucketdouble[i] = vetor[i];
                                }
                                System.out.println("\n--------------------------\n");
                                System.out.println("Método: [Bucket Sort]");
                                for(int i = 0; i < execucoes; i++){
                                    BucketVetor = new Integer[x];
                                    System.arraycopy(vetor, 0, BucketVetor, 0, vetor.length);
                                    tempoInicio = System.nanoTime();
                                    Ordenadores.BucketSort(Bucketdouble, Bucketdouble.length);
                                    tempoFim = System.nanoTime();
                                    tempoExecucao += (tempoFim - tempoInicio);
                                }
                                System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                                System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                                System.out.println("\n--------------------------\n");
                                System.out.println("=======================ORDENADO======================");
                                for (int i = 0; i < x ;i++){
                                    System.out.print(" [" + Bucketdouble[i] + "]");
                                }
                                System.out.println("\n=======================ORDENADO======================");
                                tempoExecucao = 0;
                                break;
                            default:
                                System.out.println("Opção inválida");
                        }
                    }
                    break;
                case 3:
                    System.out.println("======================");
                    System.out.println("Informe o método de teste a ser utilizado");
                    System.out.println("1 - InsertionSort");
                    System.out.println("2 - MergeSort");
                    System.out.println("3 - BubbleSort");
                    System.out.println("4 - SelectionSort");
                    System.out.println("5 - ShellSort");
                    System.out.println("6 - Heapsort");
                    System.out.println("7 - QuickSort");
                    op = scanner.nextInt();
                    switch(op){
                        case 1:
                        System.out.println("-----Ordem Crescente-----");
                        V1 = new Integer[]{1,2,3,4,5,6,7,8,9,10};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.InsertionSort(V1, V1.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Ordem Decrescente-----");
                        V2 = new Integer[]{10,9,8,7,6,5,4,3,2,1};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.InsertionSort(V2, V2.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Aleatório-----");
                        V3 = new Integer[10];
                        for (int i = 0; i < 10 ;i++){
                        V3[i] = rand.nextInt(100);
                        }
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.InsertionSort(V3, V3.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Repetido-----");
                        V4 = new Integer[]{1,2,1,2,1,2,1,2,1,2};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.InsertionSort(V4, V4.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;
                        break;

                        case 2:
                        System.out.println("-----Ordem Crescente-----");
                        V1 = new Integer[]{1,2,3,4,5,6,7,8,9,10};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.MergeSort(V1, 0, V1.length-1);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Ordem Decrescente-----");
                        V2 = new Integer[]{10,9,8,7,6,5,4,3,2,1};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.MergeSort(V2, 0, V2.length-1);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Aleatório-----");
                        V3 = new Integer[10];
                        for (int i = 0; i < 10 ;i++){
                        V3[i] = rand.nextInt(100);
                        }
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.MergeSort(V3, 0, V3.length-1);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Repetido-----");
                        V4 = new Integer[]{1,2,1,2,1,2,1,2,1,2};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.MergeSort(V4, 0, V4.length-1);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;
                        break;

                        case 3:
                        System.out.println("-----Ordem Crescente-----");
                        V1 = new Integer[]{1,2,3,4,5,6,7,8,9,10};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.BubbleSort(V1, V1.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Ordem Decrescente-----");
                        V2 = new Integer[]{10,9,8,7,6,5,4,3,2,1};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.BubbleSort(V2, V2.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Aleatório-----");
                        V3 = new Integer[10];
                        for (int i = 0; i < 10 ;i++){
                        V3[i] = rand.nextInt(100);
                        }
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.BubbleSort(V3, V3.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Repetido-----");
                        V4 = new Integer[]{1,2,1,2,1,2,1,2,1,2};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.BubbleSort(V4, V4.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;
                        break;

                        case 4:
                        System.out.println("-----Ordem Crescente-----");
                        V1 = new Integer[]{1,2,3,4,5,6,7,8,9,10};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.SelectionSort(V1, V1.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Ordem Decrescente-----");
                        V2 = new Integer[]{10,9,8,7,6,5,4,3,2,1};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.SelectionSort(V2, V2.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Aleatório-----");
                        V3 = new Integer[10];
                        for (int i = 0; i < 10 ;i++){
                        V3[i] = rand.nextInt(100);
                        }
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.SelectionSort(V3, V3.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Repetido-----");
                        V4 = new Integer[]{1,2,1,2,1,2,1,2,1,2};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.SelectionSort(V4, V4.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;
                        break;

                        case 5:
                        System.out.println("-----Ordem Crescente-----");
                        V1 = new Integer[]{1,2,3,4,5,6,7,8,9,10};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.ShellSort(V1, V1.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Ordem Decrescente-----");
                        V2 = new Integer[]{10,9,8,7,6,5,4,3,2,1};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.ShellSort(V2, V2.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Aleatório-----");
                        V3 = new Integer[10];
                        for (int i = 0; i < 10 ;i++){
                        V3[i] = rand.nextInt(100);
                        }
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.ShellSort(V3, V3.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Repetido-----");
                        V4 = new Integer[]{1,2,1,2,1,2,1,2,1,2};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.ShellSort(V4, V4.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;
                        break;

                        case 6:
                        System.out.println("-----Ordem Crescente-----");
                        V1 = new Integer[]{1,2,3,4,5,6,7,8,9,10};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.HeapSort(V1, V1.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Ordem Decrescente-----");
                        V2 = new Integer[]{10,9,8,7,6,5,4,3,2,1};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.HeapSort(V2, V2.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Aleatório-----");
                        V3 = new Integer[10];
                        for (int i = 0; i < 10 ;i++){
                        V3[i] = rand.nextInt(100);
                        }
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.HeapSort(V3, V3.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Repetido-----");
                        V4 = new Integer[]{1,2,1,2,1,2,1,2,1,2};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.HeapSort(V4, V4.length);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;
                        break;

                        case 7:
                        System.out.println("-----Ordem Crescente-----");
                        V1 = new Integer[]{1,2,3,4,5,6,7,8,9,10};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.QuickSort(V1,0,V1.length-1);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Ordem Decrescente-----");
                        V2 = new Integer[]{10,9,8,7,6,5,4,3,2,1};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.QuickSort(V2,0,V2.length-1);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Aleatório-----");
                        V3 = new Integer[10];
                        for (int i = 0; i < 10 ;i++){
                        V3[i] = rand.nextInt(100);
                        }
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.QuickSort(V3,0,V3.length-1);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;

                        System.out.println("-----Repetido-----");
                        V4 = new Integer[]{1,2,1,2,1,2,1,2,1,2};
                        for(int i = 0; i < 30; i++){
                            tempoInicio = System.nanoTime();
                            Ordenadores.QuickSort(V4,0,V4.length-1);
                            tempoFim = System.nanoTime();
                            tempoExecucao += (tempoFim - tempoInicio);
                        }
                        tempoExecucao = tempoExecucao/30;
                        System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                        tempoExecucao = 0;
                        break;
                        default:
                        System.out.println("Opção inválida");
                        break;
                    }
                    break;
                case 4:
                if(x == 0){
                    System.out.println("Primeiro crie um vetor antes de ordená-lo");
                    break;
                }
                else{
                    System.out.println("======================");
                    System.out.println("Informe o método de ordenação a ser utilizado: ");
                    System.out.println("1 - InsertionSort");
                    System.out.println("2 - MergeSort");
                    System.out.println("3 - BubbleSort");
                    System.out.println("4 - SelectionSort");
                    System.out.println("5 - ShellSort");
                    System.out.println("6 - Heapsort");
                    System.out.println("7 - QuickSort");
                    System.out.println("======================");
                    op2 = scanner.nextInt();
                    switch (op2){
                        case 1:
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Insertion Sort]");
                            System.out.println("[Ordena com comparable]");
                            for(int i = 0; i < execucoes; i++){
                                InsertionVetor = new Integer[x];
                                System.arraycopy(vetor, 0, InsertionVetor, 0, vetor.length);
                                tempoInicio = System.nanoTime();
                                Ordenadores.InsertionSort(InsertionVetor, x);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                            Ordenaint = new int[x];
                            for(int i = 0; i < x; i++){
                                Ordenaint[i] = vetor[i];
                            }
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Insertion Sort]");
                            System.out.println("[Ordena com inteiros]");
                            for(int i = 0; i < execucoes; i++){
                                tempoInicio = System.nanoTime();
                                Ordenadores.InsertionSortint(Ordenaint, x);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                        break;
                        case 2:
                        System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Merge Sort]");
                            System.out.println("[Ordena com comparable]");
                            for(int i = 0; i < execucoes; i++){
                                MergeVetor = new Integer[x];
                                System.arraycopy(vetor, 0, MergeVetor, 0, vetor.length);
                                tempoInicio = System.nanoTime();
                                Ordenadores.MergeSort(MergeVetor, 0, MergeVetor.length-1);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                            Ordenaint = new int[x];
                            for(int i = 0; i < x; i++){
                                Ordenaint[i] = vetor[i];
                            }
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Merge Sort]");
                            System.out.println("[Ordena com inteiros]");
                            for(int i = 0; i < execucoes; i++){
                                tempoInicio = System.nanoTime();
                                Ordenadores.MergeSortint(Ordenaint, 0, Ordenaint.length-1);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                        break;
                        case 3:
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Bubble Sort]");
                            System.out.println("[Ordena com comparable]");
                            for(int i = 0; i < execucoes; i++){
                                BubbleVetor = new Integer[x];
                                System.arraycopy(vetor, 0, BubbleVetor, 0, vetor.length);
                                tempoInicio = System.nanoTime();
                                Ordenadores.BubbleSort(BubbleVetor, x);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                            Ordenaint = new int[x];
                            for(int i = 0; i < x; i++){
                                Ordenaint[i] = vetor[i];
                            }
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Bubble Sort]");
                            System.out.println("[Ordena com inteiros]");
                            for(int i = 0; i < execucoes; i++){
                                tempoInicio = System.nanoTime();
                                Ordenadores.BubbleSortint(Ordenaint, Ordenaint.length);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                        break;
                        case 4:
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Selection Sort]");
                            System.out.println("[Ordena com comparable]");
                            for(int i = 0; i < execucoes; i++){
                                SelectionVetor = new Integer[x];
                                System.arraycopy(vetor, 0, SelectionVetor, 0, vetor.length);
                                tempoInicio = System.nanoTime();
                                Ordenadores.SelectionSort(SelectionVetor, SelectionVetor.length);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                            Ordenaint = new int[x];
                            for(int i = 0; i < x; i++){
                                Ordenaint[i] = vetor[i];
                            }
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Selection Sort]");
                            System.out.println("[Ordena com inteiros]");
                            for(int i = 0; i < execucoes; i++){
                                tempoInicio = System.nanoTime();
                                Ordenadores.SelectionSortint(Ordenaint, Ordenaint.length);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                        break;
                        case 5:
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Shell Sort]");
                            System.out.println("[Ordena com comparable]");
                            for(int i = 0; i < execucoes; i++){
                                ShellVetor = new Integer[x];
                                System.arraycopy(vetor, 0, ShellVetor, 0, vetor.length);
                                tempoInicio = System.nanoTime();
                                Ordenadores.ShellSort(ShellVetor, x);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                            Ordenaint = new int[x];
                            for(int i = 0; i < x; i++){
                                Ordenaint[i] = vetor[i];
                            }
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Shell Sort]");
                            System.out.println("[Ordena com inteiros]");
                            for(int i = 0; i < execucoes; i++){
                                tempoInicio = System.nanoTime();
                                Ordenadores.ShellSortint(Ordenaint, Ordenaint.length);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                        break;
                        case 6:
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Heap Sort]");
                            System.out.println("[Ordena com comparable]");
                            for(int i = 0; i < execucoes; i++){
                                HeapVetor = new Integer[x];
                                System.arraycopy(vetor, 0, HeapVetor, 0, vetor.length);
                                tempoInicio = System.nanoTime();
                                Ordenadores.HeapSort(HeapVetor, x);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                            Ordenaint = new int[x];
                            for(int i = 0; i < x; i++){
                                Ordenaint[i] = vetor[i];
                            }
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Heap Sort]");
                            System.out.println("[Ordena com inteiros]");
                            for(int i = 0; i < execucoes; i++){
                                tempoInicio = System.nanoTime();
                                Ordenadores.HeapSortint(Ordenaint, Ordenaint.length);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                        break;
                        case 7:
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Quick Sort]");
                            System.out.println("[Ordena com comparable]");
                            for(int i = 0; i < execucoes; i++){
                                QuickVetor = new Integer[x];
                                System.arraycopy(vetor, 0, QuickVetor, 0, vetor.length);
                                tempoInicio = System.nanoTime();
                                Ordenadores.QuickSort(QuickVetor,0,x-1);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                            Ordenaint = new int[x];
                            for(int i = 0; i < x; i++){
                                Ordenaint[i] = vetor[i];
                            }
                            System.out.println("\n--------------------------\n");
                            System.out.println("Método: [Quick Sort]");
                            System.out.println("[Ordena com inteiros]");
                            for(int i = 0; i < execucoes; i++){
                                tempoInicio = System.nanoTime();
                                Ordenadores.QuickSortint(Ordenaint, 0, x-1);
                                tempoFim = System.nanoTime();
                                tempoExecucao += (tempoFim - tempoInicio);
                            }
                            System.out.println("Tempo de execução (em nanossegundos): [" + tempoExecucao + "]");
                            System.out.println("Tempo de médio de execução (em nanossegundos): [" + (tempoExecucao/execucoes) + "]");
                            System.out.println("\n--------------------------\n");
                            tempoExecucao = 0;
                        break;
                        default:
                        System.out.println("Opção inválida");
                        break;
                    }
                }
                break;
                case 5:
                System.out.println("Saindo...");
                break;
                default:
                System.out.println("Opção inválida");
                break;
            }
        }
        scanner.close();
    }
}